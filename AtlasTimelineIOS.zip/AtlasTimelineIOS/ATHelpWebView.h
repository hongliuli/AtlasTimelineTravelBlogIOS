//
//  ATHelpWebView.h
//  AtlasTimelineIOS
//
//  Created by Hong on 2/27/13.
//  Copyright (c) 2013 hong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ATHelpWebView : UIViewController
@property (strong, nonatomic)  UIWebView *helpWebView;

@end

//
//  ATPreferenceEntity.m
//  AtlasTimelineIOS
//
//  Created by Hong on 1/23/13.
//  Copyright (c) 2013 hong. All rights reserved.
//

#import "ATPreferenceEntity.h"


@implementation ATPreferenceEntity

@dynamic preferenceName;
@dynamic preferenceValue;

@end

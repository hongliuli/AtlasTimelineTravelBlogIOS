//
//  ATUnsavedAnnotationView.m
//  AtlasTimelineIOS
//
//  Created by Hong on 1/5/13.
//  Copyright (c) 2013 hong. All rights reserved.
//

#import "ATUnsavedAnnotationView.h"

@implementation ATUnsavedAnnotationView

@end

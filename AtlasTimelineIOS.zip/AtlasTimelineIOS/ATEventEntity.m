//
//  ATEventEntity.m
//  AtlasTimelineIOS
//
//  Created by Hong on 2/13/13.
//  Copyright (c) 2013 hong. All rights reserved.
//

#import "ATEventEntity.h"


@implementation ATEventEntity

@dynamic address;
@dynamic eventDate;
@dynamic eventDesc;
@dynamic eventType;
@dynamic lat;
@dynamic lng;
@dynamic uniqueId;
@dynamic iconType;

@end

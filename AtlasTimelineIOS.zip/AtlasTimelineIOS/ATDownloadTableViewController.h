//
//  ATDownloadTableViewController.h
//  AtlasTimelineIOS
//
//  Created by Hong on 2/17/13.
//  Copyright (c) 2013 hong. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ATPreferenceViewController;

@interface ATDownloadTableViewController : UITableViewController

@property (nonatomic, strong) ATPreferenceViewController* parent;

@end

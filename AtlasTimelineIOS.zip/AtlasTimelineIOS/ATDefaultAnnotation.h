//
//  ATDefaultAnnotation.h
//  AtlasTimelineIOS
//
//  Created by Hong on 1/21/13.
//  Copyright (c) 2013 hong. All rights reserved.
//

#import "ATEventAnnotation.h"

@interface ATDefaultAnnotation : ATEventAnnotation

@end

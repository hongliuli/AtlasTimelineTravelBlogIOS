//
//  ATUnsavedAnnotationView.h
//  AtlasTimelineIOS
//
//  Created by Hong on 1/5/13.
//  Copyright (c) 2013 hong. All rights reserved.
//



// MAY Not need this, I can use ATEventAnnotation.h and give different

#import <Foundation/Foundation.h>

@interface ATUnsavedAnnotationView : NSObject

@end
